//
//  SensorTag.swift
//  SwiftSensorTag
//


import Foundation
import CoreBluetooth


let deviceName = "CC2650 SensorTag"

// Service UUIDs
let IRTemperatureServiceUUID = CBUUID(string: "F000AA00-0451-4000-B000-000000000000")
let AccelerometerServiceUUID = CBUUID(string: "F000AA10-0451-4000-B000-000000000000")
let HumidityServiceUUID      = CBUUID(string: "F000AA20-0451-4000-B000-000000000000")
let MagnetometerServiceUUID  = CBUUID(string: "F000AA30-0451-4000-B000-000000000000")
let BarometerServiceUUID     = CBUUID(string: "F000AA40-0451-4000-B000-000000000000")
let GyroscopeServiceUUID     = CBUUID(string: "F000AA50-0451-4000-B000-000000000000")
let LightServiceUUID         = CBUUID(string: "F000AA70-0451-4000-B000-000000000000")

// Characteristic UUIDs
let IRTemperatureDataUUID   = CBUUID(string: "F000AA01-0451-4000-B000-000000000000")
let IRTemperatureConfigUUID = CBUUID(string: "F000AA02-0451-4000-B000-000000000000")
let LightDataUUID           = CBUUID(string: "F000AA71-0451-4000-B000-000000000000")
let LightConfigUUID         = CBUUID(string: "F000AA72-0451-4000-B000-000000000000")
let AccelerometerDataUUID   = CBUUID(string: "F000AA11-0451-4000-B000-000000000000")
let AccelerometerConfigUUID = CBUUID(string: "F000AA12-0451-4000-B000-000000000000")
let HumidityDataUUID        = CBUUID(string: "F000AA21-0451-4000-B000-000000000000")
let HumidityConfigUUID      = CBUUID(string: "F000AA22-0451-4000-B000-000000000000")
let MagnetometerDataUUID    = CBUUID(string: "F000AA31-0451-4000-B000-000000000000")
let MagnetometerConfigUUID  = CBUUID(string: "F000AA32-0451-4000-B000-000000000000")
let BarometerDataUUID       = CBUUID(string: "F000AA41-0451-4000-B000-000000000000")
let BarometerConfigUUID     = CBUUID(string: "F000AA42-0451-4000-B000-000000000000")
let GyroscopeDataUUID       = CBUUID(string: "F000AA51-0451-4000-B000-000000000000")
let GyroscopeConfigUUID     = CBUUID(string: "F000AA52-0451-4000-B000-000000000000")

let MovementServiceUUID     = CBUUID(string: "F000AA80-0451-4000-B000-000000000000")
let MovementDataUUID        = CBUUID(string: "F000AA81-0451-4000-B000-000000000000")
let MovementConfigUUID      = CBUUID(string: "F000AA82-0451-4000-B000-000000000000")
let MovementPeriodUUID      = CBUUID(string: "F000AA83-0451-4000-B000-000000000000")



class SensorTag {
    
    // Check name of device from advertisement data
    class func sensorTagFound (_ advertisementData: [AnyHashable: Any]!) -> Bool {
        let nameOfDeviceFound = (advertisementData as NSDictionary).object(forKey: CBAdvertisementDataLocalNameKey) as? NSString
        return (deviceName.isEqual(nameOfDeviceFound))
    }
    
    
    // Check if the service has a valid UUID
    class func validService (_ service : CBService) -> Bool {
        print("******Service Characteristics   " )
        print(service.uuid)
        if service.uuid == IRTemperatureServiceUUID || service.uuid == AccelerometerServiceUUID ||
            service.uuid == HumidityServiceUUID || service.uuid == MagnetometerServiceUUID ||
            service.uuid == BarometerServiceUUID || service.uuid == GyroscopeServiceUUID ||
            service.uuid == MovementServiceUUID || service.uuid == LightServiceUUID {
            print("******Service Characteristics  Found" )
            print(service.uuid)
            return true
        }
        else {
            return false
        }
    }
    
    
    // Check if the characteristic has a valid data UUID
    class func validDataCharacteristic (_ characteristic : CBCharacteristic) -> Bool {
        print("******Data Characteristics   " )
        print(characteristic.uuid)
        if characteristic.uuid == IRTemperatureDataUUID || characteristic.uuid == AccelerometerDataUUID ||
            characteristic.uuid == HumidityDataUUID || characteristic.uuid == MagnetometerDataUUID ||
            characteristic.uuid == BarometerDataUUID || characteristic.uuid == GyroscopeDataUUID ||
            characteristic.uuid == MovementDataUUID || characteristic.uuid == LightDataUUID {
            print("******Data Characteristics Found   " )
            print(characteristic.uuid)
            return true
        }
        else {
            return false
        }
    }
    
    
    // Check if the characteristic has a valid config UUID
    class func validConfigCharacteristic (_ characteristic : CBCharacteristic) -> Bool {
        print("******Config Characteristics   " )
        print(characteristic.uuid)
        if characteristic.uuid == IRTemperatureConfigUUID || characteristic.uuid == AccelerometerConfigUUID ||
            characteristic.uuid == HumidityConfigUUID || characteristic.uuid == MagnetometerConfigUUID ||
            characteristic.uuid == BarometerConfigUUID || characteristic.uuid == GyroscopeConfigUUID ||
            characteristic.uuid == MovementConfigUUID  || characteristic.uuid == LightConfigUUID {
            print("******Config Characteristics Found  " )
            print(characteristic.uuid)
            return true
        }
        else {
            return false
        }
    }
    
    
        // Get labels of sensors
    class func getSensorEnvironmentLabels () -> [String] {
        let sensorLabels : [String] = [
            "Ambient Temperature",
            "IR Temperature",
            "Relative Humidity",
            "Barometer",
            "Light"
        ]
        return sensorLabels
    }
    class func getSensorMovementLabels () -> [String] {
        let sensorLabels : [String] = [
            "Accelerometer X",
            "Accelerometer Y",
            "Accelerometer Z",
            "Gyroscope X",
            "Gyroscope Y",
            "Gyroscope Z",
            "Magnetometer X",
            "Magnetometer Y",
            "Magnetometer Z"
        ]
        return sensorLabels
    }

    
    
    // Process the values from sensor
    
    
    // Convert NSData to array of bytes
    class func dataToSignedBytes16(_ value : Data) -> [Int16] {
        let count = value.count
        var array = [Int16](repeating: 0, count: count)
        (value as NSData).getBytes(&array, length:count * MemoryLayout<Int16>.size)
        return array
    }
    
    class func dataToUnsignedBytes16(_ value : Data) -> [UInt16] {
        let count = value.count
        var array = [UInt16](repeating: 0, count: count)
        (value as NSData).getBytes(&array, length:count * MemoryLayout<UInt16>.size)
        return array
    }
    
    class func dataToSignedBytes8(_ value : Data) -> [Int8] {
        let count = value.count
        var array = [Int8](repeating: 0, count: count)
        (value as NSData).getBytes(&array, length:count * MemoryLayout<Int8>.size)
        return array
    }
    
    class func dataToUnsignedBytes8(_ value : Data) -> [UInt8] {
        let count = value.count
        var array = [UInt8](repeating: 0, count: count)
        (value as NSData).getBytes(&array, length:count * MemoryLayout<UInt8>.size)
        return array
    }
    
    class func getBarometer(_ value : Data) -> Double {
        let val = dataToSignedBytes8(value)
        let pressure = Double(longSignedAtOffset(val, offset: 3)) / 100.0
        return (pressure)
    }
    
    // Get ambient temperature value
    class func getTemperatureNOTUSED(_ value : Data) -> [Double] {
        let vals = dataToSignedBytes8(value)
        let ambTemp = Double(shortSignedAtOffset(vals, offset: 2)) / 128.0
        let objTempScratch = shortSignedAtOffset(vals, offset: 0) >> 2
        let objTemp = Double(objTempScratch) * 0.03125
        
        return [ambTemp, objTemp]
    }
    
    
    
    // Get ambient temperature value
    class func getAmbientTemperature(_ value : Data) -> Double {
        let dataFromSensor = dataToSignedBytes16(value)
        //let ambientTemperature = Double(dataFromSensor[1])/128
        let ambientTemperature = Double(dataFromSensor[1] >> 2) * 0.03125
        return ambientTemperature
    }
    
    // Get object temperature value
    class func getObjectTemperature(_ value : Data, ambientTemperature : Double) -> Double {
        let dataFromSensor = dataToSignedBytes16(value)
        let objectTemperature = Double(dataFromSensor[0] >> 2) * 0.03125

        return objectTemperature
    }
    
    // Get Accelerometer values
    class func getAccelerometerData(_ value: Data) -> [Double] {
        let dataFromSensor = dataToSignedBytes8(value)
        let xVal = Double(dataFromSensor[0]) / 64
        let yVal = Double(dataFromSensor[1]) / 64
        let zVal = Double(dataFromSensor[2]) / 64 * -1
        return [xVal, yVal, zVal]
    }
    
    // Get temperature from humidity sensor
    class func getTemperature(_ value: Data) -> Double {
        let dataFromSensor = dataToUnsignedBytes16(value)
        let d  = UInt16(dataFromSensor[0])
        let temp =  (Double(d) / 65536.0) * 165.0 - 40
        return temp
    }
    // Get Relative Humidity
    class func getRelativeHumidity(_ value: Data) -> Double {
        let dataFromSensor = dataToUnsignedBytes16(value)
        var d  = UInt16(dataFromSensor[1])
        d &= ~0x0003
        let humidity =  (Double(d) / 65536.0) * 100.0
       return humidity
    }
    
    //Get Relative Light
    class func getRelativeLight(_ value: Data) -> Double {
        let dataFromSensor = dataToSignedBytes16(value)
        let light = Double(dataFromSensor[0]) / 85.0
        return light
    }
    
    // Get magnetometer values
    class func getMagnetometerData(_ value: Data) -> [Double] {
        let dataFromSensor = dataToSignedBytes16(value)
        let xVal = Double(dataFromSensor[0]) * 2000 / 65536 * -1
        let yVal = Double(dataFromSensor[1]) * 2000 / 65536 * -1
        let zVal = Double(dataFromSensor[2]) * 2000 / 65536
        return [xVal, yVal, zVal]
    }
    
    // Get gyroscope values
    class func getGyroscopeData(_ value: Data) -> [Double] {
        let dataFromSensor = dataToSignedBytes16(value)
        let yVal = Double(dataFromSensor[0]) * 500 / 65536 * -1
        let xVal = Double(dataFromSensor[1]) * 500 / 65536
        let zVal = Double(dataFromSensor[2]) * 500 / 65536
        return [xVal, yVal, zVal]
    }
    
    
    // Get Movement values
    class func getMovementData(_ value: Data) -> [Double] {
        let vals = dataToSignedBytes8(value)
        
        let gyroxVal = (Double(shortSignedAtOffset(vals, offset: 0)) / 32768.0) * 255.0 * 1.0
        let gyroyVal = (Double(shortSignedAtOffset(vals, offset: 2)) / 32768.0) * 255.0 * 1.0
        let gyrozVal = (Double(shortSignedAtOffset(vals, offset: 4)) / 32768.0) * 255.0 * 1.0
        
        let accXVal = (Double(shortSignedAtOffset(vals, offset: 6)) / 32768.0) * 8.0 * 1.0
        let accYVal = (Double(shortSignedAtOffset(vals, offset: 8)) / 32768.0) * 8.0 * 1.0
        let accZVal = (Double(shortSignedAtOffset(vals, offset: 10)) / 32768.0) * 8.0 * 1.0
        
        let magxVal = (Double(shortSignedAtOffset(vals, offset: 12)) / 32768.0) * 4912.0
        let magyVal = (Double(shortSignedAtOffset(vals, offset: 14)) / 32768.0) * 4912.0
        let magzVal = (Double(shortSignedAtOffset(vals, offset: 16)) / 32768.0) * 4912.0
        
        return [accXVal,accYVal,accZVal,gyroxVal,gyroyVal,gyrozVal,magxVal,magyVal,magzVal]
    }
    
    
    class func shortSignedAtOffset(_ vals: [Int8], offset: Int) -> Int16 {
        let lowerByte = Int16(vals[offset]) & 0xFF
        let upperByte = Int16(vals[offset+1]) & 0xFF
        return((upperByte<<8) + lowerByte)
        
    }
    
    class func longSignedAtOffset (_ vals: [Int8], offset: Int) -> Int32 {
        let lowerByte = Int32(vals[offset]) & 0xFF
        let middleByte = Int32(vals[offset+1]) & 0xFF
        let upperByte = Int32(vals[offset+2]) & 0xFF
        return ((upperByte<<16) + (middleByte<<8) + lowerByte)
    }
    
}
