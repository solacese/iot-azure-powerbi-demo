//
//  MqttModelController.swift
//  SwiftSensorTag
//
//  We use this class to manahe the MQTT connection shared by both View Controllers.
//  Created by Richard Lawrence on 27/09/2019.
//

import UIKit
import CocoaMQTT

class MqttModelController: NSObject, CocoaMQTTDelegate {

    static let shared = MqttModelController()
    
    public var serverHost :String = "vmr-mr8v6yiwicdj.messaging.solace.cloud"
    public var serverPort: UInt16 = 20326
    public var username:String = "solace-cloud-client"
    public var password:String = "ia8vhe2t8t2dgg1p6grf6vcocq"
    public var environmentTopic :String = "sensortag/environment"
    public var movementTopic :String = "sensortag/movement"
    public var lastEnvMessage :String = ""
    public var lastMoveMessage :String = ""
    // Publish every 3 seconds
    public var pubRate :UInt16 = 1

    private var mqtt: CocoaMQTT!
    
    private override init() {
        super.init()
    }
    
    var status: String {
        if (mqtt == nil)
        {
            return "Not Initialised"
        }
        else
        {
            return mqtt.connState.description
        }
    }
    
    var isConnected: Bool {
        return mqtt != nil && mqtt.connState == CocoaMQTTConnState.connected
    }
    
    func connect() -> Bool {
            
        self.disconnect()
        mqtt = CocoaMQTT(clientID: "SensorTag-" + String(ProcessInfo().processIdentifier), host: self.serverHost, port: self.serverPort)
        mqtt.willMessage = CocoaMQTTWill(topic: "/will", message: "dieout")
        mqtt.keepAlive = 60
        mqtt.delegate = self
        mqtt.username = self.username
        mqtt.password = self.password
        return mqtt.connect()
    }
    
    func disconnect()
    {
        if (mqtt != nil)
        {
            mqtt.disconnect()
        }
        self.lastEnvMessage = ""
        self.lastMoveMessage = ""
    }
    
    func publishEnvironmentData(withString payload: String)
    {
        if self.environmentTopic.count > 0
        {
            mqtt.publish(self.environmentTopic, withString: payload)
            self.lastEnvMessage = payload
        }
    }
    func publishMovementData(withString payload: String)
    {
        if self.movementTopic.count > 0
        {
            mqtt.publish(self.movementTopic, withString: payload)
            self.lastMoveMessage = payload
        }
    }
    
    /******* CocoaMQTTDelegate *******/
    func mqtt(_ mqtt: CocoaMQTT, didConnectAck ack: CocoaMQTTConnAck) {
        print("MQTT CONNECTED")

    }
    
    func mqtt(_ mqtt: CocoaMQTT, didPublishMessage message: CocoaMQTTMessage, id: UInt16) {
        
    }
    
    func mqtt(_ mqtt: CocoaMQTT, didPublishAck id: UInt16) {
        
    }
    
    func mqtt(_ mqtt: CocoaMQTT, didReceiveMessage message: CocoaMQTTMessage, id: UInt16) {
        
    }
    
    func mqtt(_ mqtt: CocoaMQTT, didSubscribeTopic topics: [String]) {
        
    }
    
    func mqtt(_ mqtt: CocoaMQTT, didUnsubscribeTopic topic: String) {
        
    }
    
    func mqttDidPing(_ mqtt: CocoaMQTT) {
    }
    
    func mqttDidReceivePong(_ mqtt: CocoaMQTT) {
    }
    
    func mqttDidDisconnect(_ mqtt: CocoaMQTT, withError err: Error?) {
        print("MQTT DISCONNECTED")
    }

}
