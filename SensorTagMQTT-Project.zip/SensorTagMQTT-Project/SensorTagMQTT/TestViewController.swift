//
//  TestViewController.swift
//  SensorTagMQTT
//
//  Created by Richard Lawrence on 01/10/2019.
//

import UIKit

class TestViewController: UIViewController, UITableViewDataSource {
    
    @IBOutlet var sensorTagTableView: UITableView!
    
    var allSensorLabels : [String] = ["aaa","xxx","vvv","bbbb"]
    var allSensorValues : [Double] = [12.3,56.4,67.3,7788.9]

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if (section == 0)
        {
            return 2
        } else
        {
            return self.allSensorLabels.count
        }

    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        print("section \(indexPath.section)")
        if (indexPath.section > 0)
        {
            if let thisCell = tableView.dequeueReusableCell(withIdentifier: "sensorTagTableCell") as? SensorTagTableViewCell
            {
                thisCell.sensorNameLabel.text  = allSensorLabels[indexPath.row]
                
                let valueString = NSString(format: "%.2f", allSensorValues[indexPath.row])
                thisCell.sensorValueLabel.text = valueString as String
                
                return thisCell
            }
        }
        else
        {
            if let thisCell = tableView.dequeueReusableCell(withIdentifier: "statusTableCell") //as? StatusTableViewCell
            {
                if (indexPath.row == 0)
                {
                    thisCell.textLabel?.text = "SensorTag"
                }
                else
                {
                    thisCell.textLabel?.text = "MQTT"
                }
                return thisCell
                
            }
        }
        // return the default cell if none of above succeed
        return UITableViewCell()
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        self.sensorTagTableView.dataSource = self
        //self.sensorTagTableView.register(StatusTableViewCell.self, forCellReuseIdentifier: "statusTableCell")
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
