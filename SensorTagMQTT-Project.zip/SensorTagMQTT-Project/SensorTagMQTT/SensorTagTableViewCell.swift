//
//  SensorTagTableViewCell.swift
//  SwiftSensorTag
//


import UIKit

class SensorTagTableViewCell: UITableViewCell {
    
    @IBOutlet var sensorNameLabel: UILabel!
    @IBOutlet var sensorValueLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
}
