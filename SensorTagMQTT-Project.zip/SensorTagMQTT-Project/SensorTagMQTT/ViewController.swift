//
//  ViewController.swift
//  SwiftSensorTag
//
//  Created by Richard Lawrence on 29/09/2019.
//



import UIKit
import CoreBluetooth
import CocoaMQTT

class ViewController: UIViewController, CBCentralManagerDelegate, CBPeripheralDelegate, UITableViewDataSource, UITableViewDelegate {

    var statusText : String = ""
    
    // BLE
    var centralManager : CBCentralManager!
    var sensorTagPeripheral : CBPeripheral!
    var deviceId : String!

    // Table View
    //var sensorTagTableView : UITableView!
    
    let tableSections = ["Status:", "Sensor Environment Data:", "Sensor Movement Data:"]
    
    @IBOutlet var sensorTagTableView: UITableView!
    
    // Sensor Values
    var environmentLabels : [String] = []
    var environmentValues : [Double] = []
    var movementLabels : [String] = []
    var movementValues : [Double] = []
    var ambientTemperature : Double!
    var objectTemperature : Double!
    var accelerometerX : Double!
    var accelerometerY : Double!
    var accelerometerZ : Double!
    var relativeHumidity : Double!
    var temperature : Double!
    var magnetometerX : Double!
    var magnetometerY : Double!
    var magnetometerZ : Double!
    var gyroscopeX : Double!
    var gyroscopeY : Double!
    var gyroscopeZ : Double!
    var barometer : Double!
    var light : Double!
    var count : UInt64 = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        // Initialize central manager on load
        centralManager = CBCentralManager(delegate: self, queue: nil)
        
        //self.sensorTagTableView.delegate = self
        self.sensorTagTableView.dataSource = self

        // Initialize all sensor values and labels
        movementLabels = SensorTag.getSensorMovementLabels()
        for _ in 0..<movementLabels.count {
            movementValues.append(0)
        }
        environmentLabels = SensorTag.getSensorEnvironmentLabels()
        for _ in 0..<environmentLabels.count {
            environmentValues.append(0)
        }

        MqttModelController.shared.connect()
        
        Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) {_ in
            self.sensorTagTableView.reloadSections([0], with: .none)
            self.publishData()
        }
    }
        
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /******* CBCentralManagerDelegate *******/
     
     // Check status of BLE hardware
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        if central.state == CBManagerState.poweredOn {
            // Scan for peripherals if BLE is turned on
            central.scanForPeripherals(withServices: nil, options: nil)
            self.statusText = "SensorTag: Searching for BLE Devices"
        }
        else {
            // Can have different conditions for all states if needed - show generic alert for now
            showAlertWithText(header: "Error", message: "Bluetooth switched off or not initialized")
        }
    }
    
    
    // Check out the discovered peripherals to find Sensor Tag
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber) {
        
        if SensorTag.sensorTagFound(advertisementData) == true {
            
            // Update Status Label
            self.statusText = "SensorTag: Found"
            
            self.deviceId = peripheral.identifier.uuidString
            
            // Stop scanning, set as the peripheral to use and establish connection
            self.centralManager.stopScan()
            self.sensorTagPeripheral = peripheral
            self.sensorTagPeripheral.delegate = self
            self.centralManager.connect(peripheral, options: nil)
        }
        else {
            self.statusText = "SensorTag: NOT Found"
            //showAlertWithText(header: "Warning", message: "SensorTag Not Found")
        }
    }

    
    // Discover services of the peripheral
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        self.statusText = "SensorTag: Discovering peripheral services"
        peripheral.discoverServices(nil)
    }
    
    
    // If disconnected, start searching again
    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        self.statusText = "SensorTag: Disconnected"
        central.scanForPeripherals(withServices: nil, options: nil)
    }
    
    /******* CBCentralPeripheralDelegate *******/
     
     // Check if the service discovered is valid i.e. one of the following:
     // IR Temperature Service
     // Accelerometer Service
     // Humidity Service
     // Magnetometer Service
     // Barometer Service
     // Gyroscope Service
     // (Others are not implemented)
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        self.statusText = "SensorTag: Looking at peripheral services"
        for service in peripheral.services! {
            let thisService = service as CBService
            if SensorTag.validService(thisService) {
                // Discover characteristics of all valid services
                peripheral.discoverCharacteristics(nil, for: thisService)
            }
        }
    }
    
    
    // Enable notification and sensor for each characteristic of valid service
    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        
        self.statusText = "SensorTag: Enabling sensors"
        
        var enableValue = 1
        let enablyBytes = NSData(bytes: &enableValue, length: MemoryLayout<UInt8>.size)
        
        for charateristic in service.characteristics! {
            let thisCharacteristic = charateristic as CBCharacteristic
            if SensorTag.validDataCharacteristic(thisCharacteristic) {
                // Enable Sensor Notification
                self.sensorTagPeripheral.setNotifyValue(true, for: thisCharacteristic)
            }
            
            if SensorTag.validConfigCharacteristic(thisCharacteristic) {
                // Enable Sensor
                // ?? This doesnt seem to get called, but if removed sensors dont start??
                if thisCharacteristic.uuid == MovementConfigUUID {
                    let endMarker = Data(bytes: UnsafePointer<UInt8>([0x7F, 0x02] as [UInt8]), count: 2)
                    self.sensorTagPeripheral.writeValue(endMarker, for: thisCharacteristic, type: CBCharacteristicWriteType.withResponse)
                } else {
                    self.sensorTagPeripheral.writeValue(enablyBytes as Data, for: thisCharacteristic, type: CBCharacteristicWriteType.withResponse)
                }
                
            }
            /*
            if thisCharacteristic.uuid == MovementPeriodUUID {
                var enableV = 10
                let period = NSData(bytes: &enableV, length: MemoryLayout<UInt8>.size)
                self.sensorTagPeripheral.writeValue(period as Data, for: thisCharacteristic, type: CBCharacteristicWriteType.withResponse)
            }
 */
        }
        
    }
    
    
    
    // Get data values when they are updated
    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        
        self.statusText = "SensorTag: Connected"
    
        if characteristic.uuid == IRTemperatureDataUUID {
            self.ambientTemperature = SensorTag.getAmbientTemperature((characteristic.value! as NSData) as Data)
            self.objectTemperature = SensorTag.getObjectTemperature((characteristic.value! as NSData) as Data, ambientTemperature: self.ambientTemperature)
            self.environmentValues[0] = self.ambientTemperature
            self.environmentValues[1] = self.objectTemperature
        }
        else if characteristic.uuid == HumidityDataUUID {
            self.relativeHumidity = SensorTag.getRelativeHumidity((characteristic.value! as NSData) as Data)
            self.environmentValues[2] = self.relativeHumidity
            self.temperature = SensorTag.getTemperature((characteristic.value! as NSData) as Data)
            //self.allSensorValues[0] = self.temperature
        }
        else if characteristic.uuid == BarometerDataUUID {
            //println("BarometerDataUUID")
            let value = SensorTag.getBarometer(characteristic.value!)
            self.barometer = value
            self.environmentValues[3] = value

        }
        else if characteristic.uuid == LightDataUUID {
            let value = SensorTag.getRelativeLight(characteristic.value!)
            if (value >= 0)
            {
                self.light = value
                self.environmentValues[4] = value
            }
        }
        else if characteristic.uuid == MovementDataUUID {
            //print("Movement Data")
            //print(characteristic.value!)
            self.movementValues = SensorTag.getMovementData(characteristic.value!)
            self.accelerometerX = self.movementValues[0]
            self.accelerometerY = self.movementValues[1]
            self.accelerometerZ = self.movementValues[2]
            
            self.gyroscopeX = self.movementValues[3]
            self.gyroscopeY = self.movementValues[4]
            self.gyroscopeZ = self.movementValues[5]

            self.magnetometerX = self.movementValues[6]
            self.magnetometerY = self.movementValues[7]
            self.magnetometerZ = self.movementValues[8]
        
        }
        
        self.sensorTagTableView.reloadData()
    }
    
    
    func publishData()
    {
        if (MqttModelController.shared.pubRate <= 0)
        {
            return
        }
        if (count % (UInt64)(MqttModelController.shared.pubRate) == 0)
        {
            if (MqttModelController.shared.isConnected && self.statusText.isEqual("SensorTag: Connected"))
            {

                let date = Date()
                
                let formatter = ISO8601DateFormatter();//DateFormatter()
                //formatter.dateFormat = "yyyy-MM-ddTHH:mm:ss.SSS"
                let timeString = "\(formatter.string(from: date))"
                
                var payload : String = "{\"type\":\"environment\",\"time\":\"\(timeString)\""
                if (self.deviceId != nil)
                {
                    /**
                    if ((count % 2) == 0)
                    {
                        payload = payload + ",\"device_id\":\"test_device\""
                    }
                    else
                    {
                        payload = payload + ",\"device_id\":\"\(self.deviceId!)\""
                    }
                    **/
                    payload = payload + ",\"device_id\":\"\(self.deviceId!)\""
                }
                var doSend:Bool = false
                if (self.ambientTemperature != nil)
                {
                    payload = payload + ",\"ambient_temp\":\((self.ambientTemperature!*100).rounded()/100)"
                    doSend = true
                }
                if (self.objectTemperature != nil)
                {
                    payload = payload + ",\"ir_temp\":\((self.objectTemperature!*100).rounded()/100)"
                    doSend = true
                }
                if (self.relativeHumidity != nil)
                {
                    payload = payload + ",\"humidity\":\((self.relativeHumidity!*100).rounded()/100)"
                    doSend = true
                }
                if (self.barometer != nil)
                {
                    doSend = true
                    payload = payload + ",\"pressure\":\((self.barometer!*100).rounded()/100)"
                }
                if (self.light != nil)
                {
                    payload = payload + ",\"light\":\((self.light!*100).rounded()/100)"
                    doSend = true
                }
                payload = payload + "}"
            
                if doSend
                {
                    MqttModelController.shared.publishEnvironmentData(withString: payload)
                    print ("published: "+payload)
                    
                }
                
                payload = "{\"type\":\"movement\",\"time\":\"\(timeString)\""
                if (self.deviceId != nil)
                {
                    payload = payload + ",\"device_id\":\"\(self.deviceId!)\""
                }
                doSend = false
                if (self.accelerometerX != nil)
                {
                    payload = payload + ",\"accelerometerX\":\((self.accelerometerX!*100).rounded()/100)"
                    doSend = true
                }
                if (self.accelerometerY != nil)
                {
                    payload = payload + ",\"accelerometerY\":\((self.accelerometerY!*100).rounded()/100)"
                    doSend = true
                }
                if (self.accelerometerZ != nil)
                {
                    payload = payload + ",\"accelerometerZ\":\((self.accelerometerZ!*100).rounded()/100)"
                    doSend = true
                }
                if (self.gyroscopeX != nil)
                {
                    payload = payload + ",\"gyroscopeX\":\((self.gyroscopeX!*100).rounded()/100)"
                    doSend = true
                }
                if (self.gyroscopeY != nil)
                {
                    payload = payload + ",\"gyroscopeY\":\((self.gyroscopeY!*100).rounded()/100)"
                    doSend = true
                }
                if (self.gyroscopeZ != nil)
                {
                    payload = payload + ",\"gyroscopeZ\":\((self.gyroscopeZ!*100).rounded()/100)"
                    doSend = true
                }
                if (self.magnetometerX != nil)
                {
                    payload = payload + ",\"magnetometerX\":\((self.magnetometerX!*100).rounded()/100)"
                    doSend = true
                }
                if (self.magnetometerY != nil)
                {
                    payload = payload + ",\"magnetometerY\":\((self.magnetometerY!*100).rounded()/100)"
                    doSend = true
                }
                if (self.magnetometerZ != nil)
                {
                    payload = payload + ",\"magnetometerZ\":\((magnetometerZ!*100).rounded()/100)"
                    doSend = true
                }
                payload = payload + "}"
                
                if doSend
                {
                    MqttModelController.shared.publishMovementData(withString: payload)
                    print ("published: "+payload)
                }
          }
        }
        count+=1

    }
    
    
    /******* UITableViewDataSource *******/
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if (section == 0)
        {
            return 2
        }
        else if section == 1
        {
            return self.environmentLabels.count
        }
        else
        {
            return self.movementLabels.count
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.tableSections.count
    }
    /*
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 1.0
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 32.0
    }*/
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return self.tableSections[section]
    }
/*
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 36.0
        //return UITableViewAutomaticDimension //46.0
    }
 */
    /******* UITableViewDelegate *******/
    

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if (indexPath.section > 0)
        {
            if let thisCell = tableView.dequeueReusableCell(withIdentifier: "sensorTagTableCell") as? SensorTagTableViewCell
            {
                if (indexPath.section == 1)
                {
                    thisCell.sensorNameLabel.text  = environmentLabels[indexPath.row]
                
                    let valueString = NSString(format: "%.2f", environmentValues[indexPath.row])
                    thisCell.sensorValueLabel.text = valueString as String
                }
                else
                {
                    thisCell.sensorNameLabel.text  = movementLabels[indexPath.row]
                    
                    let valueString = NSString(format: "%.2f", movementValues[indexPath.row])
                    thisCell.sensorValueLabel.text = valueString as String
                }
                
                return thisCell
           }
        }
        else
        {
            if let thisCell = tableView.dequeueReusableCell(withIdentifier: "statusTableCell") //as? StatusTableViewCell
            {
                if (indexPath.row == 0)
                {
                    thisCell.textLabel?.text = statusText
                    //thisCell.title.text = "Sensor Tag"
                    //hisCell.subtitle.text = statusText

                }
                else
                {
                    thisCell.textLabel?.text = String("MQTT: " + MqttModelController.shared.status)
                    //thisCell.title.text = "MQTT"
                    //thisCell.subtitle.text = MqttModelController.shared.status

                }
                return thisCell

            }
        }
        // return the default cell if none of above succeed
        return UITableViewCell()

    }
    
    /******* Helper *******/
     
     // Show alert
    func showAlertWithText (header : String = "Warning", message : String) {
        let alert = UIAlertController(title: header, message: message, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
        alert.view.tintColor = UIColor.red
        self.present(alert, animated: true, completion: nil)
    }
    

}



