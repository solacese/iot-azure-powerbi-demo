//
//  MqttViewController.swift
//  SensorTagMQTT
//
//  Created by Richard Lawrence on 29/09/2019.
//

import UIKit

class MqttViewController: UIViewController {
    

    @IBOutlet var serverTextField: UITextField!
    @IBOutlet var portTextField: UITextField!
    @IBOutlet var usernameTextField: UITextField!
    @IBOutlet var passwordTextField: UITextField!
    @IBOutlet var envTopicTextField: UITextField!
    @IBOutlet var moveTopicTextField: UITextField!
    @IBOutlet var pubRateTextField: UITextField!
    @IBOutlet var statusLabel: UILabel!
    @IBOutlet var envLogLabel: UILabel!
    @IBOutlet var moveLogLabel: UILabel!
    
    @IBAction func serverTextFieldDone(_ sender: UITextField) {
        sender.resignFirstResponder()
    }
    @IBAction func portTextFieldDone(_ sender: UITextField) {
    }
    @IBAction func usernameTextFieldDone(_ sender: UITextField) {
        sender.resignFirstResponder()
    }
    @IBAction func passwordTextFieldDone(_ sender: UITextField) {
        sender.resignFirstResponder()
    }
    
    @IBAction func envTopicTextFieldDone(_ sender: UITextField) {
        sender.resignFirstResponder()
    }
    @IBAction func moveTopicTextFieldDone(_ sender: UITextField) {
        sender.resignFirstResponder()
    }
    @IBAction func pubRateTextFieldDone(_ sender: UITextField) {
        sender.resignFirstResponder()
    }
    
    @IBOutlet var scrollView: UIScrollView!
    
    @IBAction func onConnect(_ sender: UIButton) {
        MqttModelController.shared.serverHost = self.serverTextField.text ?? ""
        MqttModelController.shared.serverPort = UInt16(self.portTextField.text ?? "1883") ?? 1883
        MqttModelController.shared.username = self.usernameTextField.text ?? ""
        MqttModelController.shared.password = self.passwordTextField.text ?? ""
        MqttModelController.shared.environmentTopic = self.envTopicTextField.text ?? ""
        MqttModelController.shared.movementTopic = self.moveTopicTextField.text ?? ""
        MqttModelController.shared.pubRate = UInt16(self.pubRateTextField.text ?? "3") ?? 3
        MqttModelController.shared.connect()
        self.statusLabel.text = "Status: " + MqttModelController.shared.status
        self.envLogLabel.text = ""
        self.moveLogLabel.text = ""
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.serverTextField.text = MqttModelController.shared.serverHost
        self.portTextField.text = String (MqttModelController.shared.serverPort)
        self.usernameTextField.text = MqttModelController.shared.username
        self.passwordTextField.text = MqttModelController.shared.password
        self.envTopicTextField.text = MqttModelController.shared.environmentTopic
        self.moveTopicTextField.text = MqttModelController.shared.movementTopic
        self.pubRateTextField.text = String (MqttModelController.shared.pubRate)
        self.statusLabel.text = "Status: " + MqttModelController.shared.status
        self.envLogLabel.text = MqttModelController.shared.lastEnvMessage
        self.moveLogLabel.text = MqttModelController.shared.lastMoveMessage

        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name:NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name:NSNotification.Name.UIKeyboardWillHide, object: nil)

        Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) {_ in
            self.statusLabel.text = "Status: " + MqttModelController.shared.status
            self.envLogLabel.text = MqttModelController.shared.lastEnvMessage
            self.moveLogLabel.text = MqttModelController.shared.lastMoveMessage
        }

        // Do any additional setup after loading the view.
    }

    @objc func keyboardWillShow(notification:NSNotification){
        
        var userInfo = notification.userInfo!
        var keyboardFrame:CGRect = (userInfo[UIKeyboardFrameBeginUserInfoKey] as! NSValue).cgRectValue
        keyboardFrame = self.view.convert(keyboardFrame, from: nil)
        
        var contentInset:UIEdgeInsets = self.scrollView.contentInset
        contentInset.bottom = keyboardFrame.size.height
        scrollView.contentInset = contentInset
    }
    
    @objc func keyboardWillHide(notification:NSNotification){
        
        let contentInset:UIEdgeInsets = UIEdgeInsets.zero
        scrollView.contentInset = contentInset
    }

    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
